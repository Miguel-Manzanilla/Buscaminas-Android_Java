package es.riberadeltajo.buscaminasmiguelmanzanillaocana;

public class Bomba {
    public String Nombre;
    public int Imagen;

    public Bomba(String nombre, int imagen) {
        Nombre = nombre;
        Imagen = imagen;
    }
}
